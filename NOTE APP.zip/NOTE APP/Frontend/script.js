const API_URL = "http://localhost:5000/api/notes"; // backend URL

const addNoteBtn = document.getElementById("addNoteBtn");
const notesContainer = document.getElementById("notesContainer");

async function fetchNotes() {
  const res = await fetch(API_URL);
  const notes = await res.json();

  notesContainer.innerHTML = "";
  notes.forEach(note => {
    const noteCard = document.createElement("div");
    noteCard.className = "bg-white p-4 rounded-lg shadow-md";
    noteCard.innerHTML = `
      <h2 class="text-lg font-semibold mb-2">${note.title}</h2>
      <p class="text-gray-600 mb-4">${note.content}</p>
      <button onclick="deleteNote('${note._id}')" class="text-red-600 hover:underline">Delete</button>
    `;
    notesContainer.appendChild(noteCard);
  });
}

addNoteBtn.addEventListener("click", async () => {
  const title = document.getElementById("title").value;
  const content = document.getElementById("content").value;

  if (!title || !content) {
    alert("Please fill both fields!");
    return;
  }

  await fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ title, content }),
  });

  document.getElementById("title").value = "";
  document.getElementById("content").value = "";

  fetchNotes();
});

async function deleteNote(id) {
  await fetch(`${API_URL}/${id}`, { method: "DELETE" });
  fetchNotes();
}

// load notes when page opens
fetchNotes();
